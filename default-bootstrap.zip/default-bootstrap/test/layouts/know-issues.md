# Know Issues
1. **margin**: doesn't capture
2. **font extension**: only support for *.ttf files
