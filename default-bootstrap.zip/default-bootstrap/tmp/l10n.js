/**
 *  @name L10n
 *  @description Localization
 *  @version 1.0
 */
var L10n = {
  group: {
    key: 'value'
  }
};
